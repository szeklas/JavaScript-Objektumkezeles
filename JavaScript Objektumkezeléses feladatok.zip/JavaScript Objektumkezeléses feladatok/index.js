//DOLGOZÓK OBJEKTUMOS FELADAT

const Dolgozok = [{
    nev: "Koaxk Ábel",
    kor: 23,
    fizetes: 400000,
    beosztas: "Rendszergazda"
},
{
    nev: "Zsíros B. Ödön",
    kor: 45,
    fizetes: 1200000,
    beosztas: "Ügyvezető Igazgató"
},
{
    nev: "Meg Győző",
    kor: 32,
    fizetes: 600000,
    beosztas: "Marketing Manager"
},
{
    nev: "Békés Csaba",
    kor: 63,
    fizetes: 180000,
    beosztas: "Takarító"
},
{
    nev: "Pofá Zoltán",
    kor: 25,
    fizetes: 300000,
    beosztas: "Biztonsági Őr"
},
{
    nev: "Fejet Lenke",
    kor: 22,
    fizetes: 220000,
    beosztas: "Irodai Titkár"
},
{
    nev: "Vak Cina",
    kor: 30,
    fizetes: 500000,
    beosztas: "Üzem Orvos"
}
]

console.log("//DOLGOZÓK OBJEKTUMOS FELADAT")

function HaviKoltseg(vizsgaltTomb){
    let osszKoltseg=0
    for(let i=0;i<vizsgaltTomb.length;i++){
        osszKoltseg+=vizsgaltTomb[i].fizetes
    }
    return osszKoltseg
}
console.log("Dolgozók havi összfizetése: "+HaviKoltseg(Dolgozok)+" Ft")




function LegtobbetKereso(vizsgaltTomb){
    let maxKeresetIndex=0
    for(let i=0;i<vizsgaltTomb.length;i++){
        if(vizsgaltTomb[i].fizetes>vizsgaltTomb[maxKeresetIndex].fizetes){
            maxKeresetIndex=i
        }
    }
    return maxKeresetIndex
}

let legtobbetKereso=LegtobbetKereso(Dolgozok)
console.log("Legtöbbet kereső dolgozó neve: "+Dolgozok[legtobbetKereso].nev)
console.log("Legtöbbet kereső dolgozó fizetése: "+Dolgozok[legtobbetKereso].fizetes+" Ft")




function LegfiatalabbDolgozo(vizsgaltTomb){
    let legfiatalabbDolgozoIndex=0
    for(let i=0;i<vizsgaltTomb.length;i++){
        if(vizsgaltTomb[i].kor<vizsgaltTomb[legfiatalabbDolgozoIndex].kor){
            legfiatalabbDolgozoIndex=i
        }
    }
    return legfiatalabbDolgozoIndex
}
let legfiatalabb=LegfiatalabbDolgozo(Dolgozok)
console.log("A legfiatalabb dolgozó a cégnél: "+Dolgozok[legfiatalabb].nev)
console.log("A legfiatalabb dolgozó életkora: "+Dolgozok[legfiatalabb].kor)




function LegfiatalabbDolgozoBernoveles(vizsgaltTomb){
    let legfiatalabbDolgozoIndex=LegfiatalabbDolgozo(vizsgaltTomb)
    vizsgaltTomb[legfiatalabbDolgozoIndex].fizetes+=30000
    console.log("A legfiatalabb dolgozó fizetése a bérnövelés után: "+vizsgaltTomb[legfiatalabbDolgozoIndex].fizetes+" Ft")
}
LegfiatalabbDolgozoBernoveles(Dolgozok)




function AtlagFizetes(vizsgaltTomb){
    let osszKoltseg=HaviKoltseg(vizsgaltTomb)
    return osszKoltseg/vizsgaltTomb.length
}
console.log("Dolgozók havi átlagkeresete: "+AtlagFizetes(Dolgozok)+" Ft")



console.log("Átlag alatti fizetések bérnövelése 10%-al: ")
function AtlagFizetesAlattiakBernoveles(vizsgaltTomb){
    let fizetesEmelesEzAlatt=AtlagFizetes(vizsgaltTomb)
    let ujAdatok=[]
    for(let i=0;i<vizsgaltTomb.length;i++){
        if(vizsgaltTomb[i].fizetes<fizetesEmelesEzAlatt){
            let ujErtek={
                nev:vizsgaltTomb[i].nev,
                fizetes:Math.round(vizsgaltTomb[i].fizetes*=1.1)
            }
            ujAdatok.push(ujErtek)
        }
    }
    return ujAdatok
}
console.log(AtlagFizetesAlattiakBernoveles(Dolgozok))




function LegidosebbDolgozo(vizsgaltTomb){
    let legidosebbDolgozoIndex=0
    for(let i=0;i<vizsgaltTomb.length;i++){
        if(vizsgaltTomb[i].kor>vizsgaltTomb[legidosebbDolgozoIndex].kor){
            legidosebbDolgozoIndex=i
        }
    }
    return legidosebbDolgozoIndex
}
let legidosebb=LegidosebbDolgozo(Dolgozok)
console.log("Legidősebb dolgozó a cégnél: "+Dolgozok[legidosebb].nev)
console.log("Legidősebb dolgozó életkora: "+Dolgozok[legidosebb].kor)




function Nyugdij(vizsgaltTomb){
    let legidosebbDolgozoIndex=LegidosebbDolgozo(vizsgaltTomb)
    let nyugdij=65-vizsgaltTomb[legidosebbDolgozoIndex].kor
    return nyugdij
}
console.log("A nyugdíjig hátralévő évek száma: "+Nyugdij(Dolgozok))



//EURÓPAI UNIÓ OBJEKTUMOS FELADAT

const EuropaiUnio = [{
    orszag: "Ausztria",
    csatlakozas: "1995.01.01"
},
{
    orszag: "Belgium",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Bulgária",
    csatlakozas: "2007.01.01"
},
{
    orszag: "Ciprus",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Csehország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Dánia",
    csatlakozas: "1973.01.01"
},
{
    orszag: "Egyesült Királyság",
    csatlakozas: "1973.01.01"
},
{
    orszag: "Észtország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Finnország",
    csatlakozas: "1995.01.01"
},
{
    orszag: "Franciaország",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Görögország",
    csatlakozas: "1981.01.01"
},
{
    orszag: "Hollandia",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Horvátország",
    csatlakozas: "2013.07.01"
},
{
    orszag: "Írország",
    csatlakozas: "1973.01.01"
},
{
    orszag: "Lengyelország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Lettország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Litvánia",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Luxemburg",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Magyarország",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Málta",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Németország",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Olaszország",
    csatlakozas: "1958.01.01"
},
{
    orszag: "Portugália",
    csatlakozas: "1986.01.01"
},
{
    orszag: "Románia",
    csatlakozas: "2007.01.01"
},
{
    orszag: "Spanyolország",
    csatlakozas: "1986.01.01"
},
{
    orszag: "Svédország",
    csatlakozas: "1995.01.01"
},
{
    orszag: "Szlovákia",
    csatlakozas: "2004.05.01"
},
{
    orszag: "Szlovénia",
    csatlakozas: "2004.05.01"
}
]

console.log("//EURÓPAI UNIÓ OBJEKTUMOS FELADAT")

function EUTagokSzama(vizsgaltTomb){
    return vizsgaltTomb.length
}
console.log("EU tagok száma: "+EUTagokSzama(EuropaiUnio))



function CsatlakozasAdottEvben(vizsgaltTomb,adottEv){
    let voltECsatlakozas=false
   for(let i=0;i<vizsgaltTomb.length;i++){
    if(vizsgaltTomb[i].csatlakozas.substr(0,4)==adottEv){
        voltECsatlakozas=true
        }
   }
   if(voltECsatlakozas==true){
    console.log(`${adottEv} évjében volt csatlakozás`)
   }
   else{
    console.log(`${adottEv} évjében NEM volt csatlakozás`)
   }

}
CsatlakozasAdottEvben(EuropaiUnio,"1995")




function HanyOrszagCsatlakozottAdottEvben(vizsgaltTomb,adottEv){
    let csatlakozasokSzama=0
    for(let i=0;i<vizsgaltTomb.length;i++){
        if(vizsgaltTomb[i].csatlakozas.substr(0,4)==adottEv){
            csatlakozasokSzama++
        }
    }
    console.log(`${adottEv} évjében ennyi ország csatlakozott: ${csatlakozasokSzama}`)
}
HanyOrszagCsatlakozottAdottEvben(EuropaiUnio,"2007")




function CsatlakozottEAzAdottOrszag(vizsgaltTomb,orszagNeve){
    let csatlakozottE=false
    for(let i=0;i<vizsgaltTomb.length;i++){
        if(vizsgaltTomb[i].orszag.toLowerCase()==orszagNeve.toLowerCase()){
            csatlakozottE=true
        }
    }
    if(csatlakozottE==true){
        console.log(`${orszagNeve} csatlakozott az EU-hoz`)
    }
    else{
        console.log(`${orszagNeve} NEM csatlakozott.`)
    }
}
CsatlakozottEAzAdottOrszag(EuropaiUnio,"Ausztria")
CsatlakozottEAzAdottOrszag(EuropaiUnio,"ausztria")




function AdottHonapbanCsatlakozas(vizsgaltTomb,honap){
    let voltECsatlakozas=false
    for(let i=0;i<vizsgaltTomb.length;i++){
        if(vizsgaltTomb[i].csatlakozas.slice(5,7)==honap){
            voltECsatlakozas=true
        }
    }
    if(voltECsatlakozas==true){
        console.log(`${honap} hónapban volt csatlakozás`)
    }
    else{
        console.log(`${honap} hónapban NEM volt csatlakozás`)
    }
}
AdottHonapbanCsatlakozas(EuropaiUnio,"05")
AdottHonapbanCsatlakozas(EuropaiUnio,"12")




function UtoljaraCsatlakozott(vizsgaltTomb){
    let legutolsoCsatlakozas=vizsgaltTomb[0].csatlakozas.substr(0,4)
    let legutolsoCsatlakozasIndex=0
    for(let i=0;i<vizsgaltTomb.length;i++){
        if(vizsgaltTomb[i].csatlakozas.substr(0,4)>legutolsoCsatlakozas){
            legutolsoCsatlakozas=vizsgaltTomb[i].csatlakozas.substr(0,4)
            legutolsoCsatlakozasIndex=i
        }
    }
    return legutolsoCsatlakozasIndex
}
let legutoljaraCsatlakozott=UtoljaraCsatlakozott(EuropaiUnio)
console.log(EuropaiUnio[legutoljaraCsatlakozott].orszag)
console.log(EuropaiUnio[legutoljaraCsatlakozott].csatlakozas)



console.log("Melyik évben hány ország csatlakozott: ")
function EvKivalogato(vizsgaltTomb){
    let evszamok=[]
    for(let i=0;i<vizsgaltTomb.length;i++){
        let szerepelE=false
        for(let j=0;j<evszamok.length;j++){
            if(vizsgaltTomb[i].csatlakozas.substr(0,4)==evszamok[j]){
                szerepelE=true
            }
        }
        if(szerepelE==false){
            evszamok.push(vizsgaltTomb[i].csatlakozas.substr(0,4))
        }
    }
    return evszamok
}
console.log(EvKivalogato(EuropaiUnio))



function EvMegszamlalo(vizsgaltTomb,evLista){
    let evMennyiseg=[]
    for(let i=0;i<evLista.length;i++){
        evMennyiseg.push(0)
    }
    for(let i=0;i<vizsgaltTomb.length;i++){
        for(let j=0;j<evLista.length;j++){
            if(vizsgaltTomb[i].csatlakozas.substr(0,4)==evLista[j]){
                evMennyiseg[j]++
            }
        }
    }
    return evMennyiseg
}

function StatisztikaKiirato(evLista,evMennyiseg){
    for(let i=0;i<evLista.length;i++){
        console.log(evLista[i]+":"+evMennyiseg[i])
    }
}
StatisztikaKiirato(EvKivalogato(EuropaiUnio),EvMegszamlalo(EuropaiUnio,EvKivalogato(EuropaiUnio)))




//FIFA OBJEKTUM 


const csapatAdat = [
    "Anglia;4;0;1662", 
    "Argentína;10;0;1614", 
    "Belgium;1;0;1752", 
    "Brazília;3;-1;1719", 
    "Chile;17;-3;1576", 
    "Dánia;14;-1;1584", 
    "Franciaország;2;1;1725", 
    "Hollandia;13;3;1586", 
    "Horvátország;8;-1;1625", 
    "Kolumbia;9;-1;1622", 
    "Mexikó;12;0;1603", 
    "Németország;16;-1;1580", 
    "Olaszország;15;1;1583", 
    "Peru;19;0;1551", 
    "Portugália;5;1;1643", 
    "Spanyolország;7;2;1631", 
    "Svájc;11;0;1604", 
    "Svédország;18;0;1560", 
    "Szenegál;20;0;1546", 
    "Uruguay;6;-1;1639"
    ];


    console.log("//FIFA OBJEKTUM FELADAT")

    function Objektumfeltolto(feltoltendoElem){
        let adatok=[]
        for(let i=0;i<feltoltendoElem.length;i++){
            let daraboltAdatsor=feltoltendoElem[i].split(";")
            let objektum={
                nev:daraboltAdatsor[0],
                helyezes:Number(daraboltAdatsor[1]),
                valtozas:Number(daraboltAdatsor[2]),
                pont:Number(daraboltAdatsor[3])
            }
            adatok.push(objektum)
        }
        return adatok
    }

    const fifaAdatok=Objektumfeltolto(csapatAdat)
    console.log(fifaAdatok)


    
    function CsapatokSzama(vizsgaltTomb){
        return vizsgaltTomb.length
    }
    console.log("Csapatok száma: "+CsapatokSzama(fifaAdatok))




    function Atlagpontszam(vizsgaltTomb){
        let osszpontszam=0
        for(let i=0;i<vizsgaltTomb.length;i++){
            osszpontszam+=vizsgaltTomb[i].pont
        }
        return [osszpontszam,Math.round(osszpontszam/vizsgaltTomb.length)]
    }
    let osszpontszam=Atlagpontszam(fifaAdatok)
    let atlagpontszam=Atlagpontszam(fifaAdatok)

    console.log("Csapatok összpontszáma: "+osszpontszam[0])
    console.log("Csapatok átlagpontszáma: "+atlagpontszam[1])




    function AtlagpontszamFelettiek(vizsgaltTomb){
        let atlagpont=atlagpontszam[1]
        let atlagFelettiek=[]
        for(let i=0;i<vizsgaltTomb.length;i++){
            if(vizsgaltTomb[i].pont>atlagpont){
                let ujObjektum={
                    nev:vizsgaltTomb[i].nev,
                    helyezes:vizsgaltTomb[i].helyezes,
                    valtozas:vizsgaltTomb[i].valtozas,
                    pont:vizsgaltTomb[i].pont
                }
                atlagFelettiek.push(ujObjektum)
            }
        }
        return atlagFelettiek
    }
    console.log(AtlagpontszamFelettiek(fifaAdatok))



    function LegtobbetJavitoCsapat(vizsgaltTomb){
        let legtobbetJavitoIndex=0
        for(let i=0;i<vizsgaltTomb.length;i++){
            if(vizsgaltTomb[i].valtozas>vizsgaltTomb[legtobbetJavitoIndex].valtozas){
                legtobbetJavitoIndex=i
            }
        }
        return legtobbetJavitoIndex
    }
    let legtobbetJavitoCsapat=LegtobbetJavitoCsapat(fifaAdatok)
    console.log("A legtöbbet javító csapat neve: "+fifaAdatok[legtobbetJavitoCsapat].nev)
    console.log("Legtöbbet javító csapat változása: "+fifaAdatok[legtobbetJavitoCsapat].valtozas)
    console.log("Legtöbbet javító csapat helyezése: "+fifaAdatok[legtobbetJavitoCsapat].helyezes)




    function AdottCsapatSzerepelE(vizsgaltTomb,csapatNeve){
        let szerepelE=false
        for(let i=0;i<vizsgaltTomb.length;i++){
            if(vizsgaltTomb[i].nev.toLowerCase()==csapatNeve.toLowerCase()){
                szerepelE=true
            }
        }
        if(szerepelE==true){
            console.log(`${csapatNeve} szerepel a ranglistán`)
        }
        else{
            console.log(`${csapatNeve} NEM szerepel a ranglistán`)
        }
    }
    console.log("Szerepel -e az adott ország a ranglistán: ")
    AdottCsapatSzerepelE(fifaAdatok,"magyarország")




    function ValtozasTipusok(vizsgaltTomb){
        let valtozasTipusok=[];
        for(let i=0;i<vizsgaltTomb.length;i++){
            let szerepelE=false;
            for(let j=0;j<valtozasTipusok.length;j++){
                if(vizsgaltTomb[i].valtozas==valtozasTipusok[j])
                {
                    szerepelE=true;
                }
            }
            if(szerepelE==false){
                valtozasTipusok.push(vizsgaltTomb[i].valtozas);
            }
        }
        return valtozasTipusok;
    }
    
    function ValtozasokMennyisege(vizsgaltTomb,valtozasTipusok){
        let valtozasokMennyisege=[];
        for(let i=0;i<valtozasTipusok.length;i++){
            valtozasokMennyisege.push(0);
        }
        for(let i=0;i<vizsgaltTomb.length;i++){
            for(let j=0;j<valtozasTipusok.length;j++){
                if(vizsgaltTomb[i].valtozas==valtozasTipusok[j])
                {
                    valtozasokMennyisege[j]++;
                }
            }
        }
        return valtozasokMennyisege;
    }



    function ValtozasKiir(valtozasTipusok,valtozasMennyisegek){
        for(let i=0;i<valtozasTipusok.length;i++){
            if(valtozasMennyisegek[i]>1){
                console.log(valtozasTipusok[i]+":"+valtozasMennyisegek[i])
            }
        }
    }
    console.log("Helyezés változások típusai és azoknak a mennyiségei amennyiben 1-nél több: ")
    ValtozasKiir(ValtozasTipusok(fifaAdatok),ValtozasokMennyisege(fifaAdatok,ValtozasTipusok(fifaAdatok)))